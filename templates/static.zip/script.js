console.log("Static site running");
