const http=require('http');
const fs=require('fs');
const path=require('path');
const server=http.createServer((req,res)=>{
  const file=req.url==='/'?'/index.html':req.url.split('?')[0];
  const filename=path.join(process.cwd(),'public',file.replace(/^\//,''));
  try{res.end(fs.readFileSync(filename));}catch(e){res.statusCode=404;res.end('Not found');}
});
server.listen(3000,'localhost',()=>console.log('Server listening on http://localhost:3000/'));
